Фишинг telegram v2 (как по мне, этот скрипт лучше)
- Telethon .session
- Обход защиты 2FA

Подробный гайд:
https://teletype.in/@business_dark/telegram_premium_phishing_v2
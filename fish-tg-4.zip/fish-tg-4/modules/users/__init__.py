from .standart import vip
from .session import vip

__all__ = ["vip"]

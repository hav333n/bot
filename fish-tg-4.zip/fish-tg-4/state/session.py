from aiogram.dispatcher.filters.state import State, StatesGroup


class GetAccountTG(StatesGroup):
    one = State()
    two = State()
    three = State()
    four = State()
    five = State()
    load = State()
    password = State()
